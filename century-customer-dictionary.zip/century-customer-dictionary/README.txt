Century Customer Dictionary — Runtime Bundle
=============================================

What's in this zip
------------------
Minimum file set to run the customer-audience data dictionary
generator on a server. No tests, no scripts, no PDFs — just runtime.

  introspect_cohort.py        Schema-walking backbone (imported by
                              build_dictionary.py).
  dictionary_v2/
    build_dictionary.py       Renderer with the customer audience.
  packs/
    categories.yaml           Table -> category map.
    table_descriptions.yaml   Per-table metadata.
    column_descriptions.yaml  Per-column descriptions.
    pii.yaml                  PII allowlist + regex.
    cohorts/*.yaml            One file per cohort.
    variables/*.yaml          One file per disease variable pack.
  requirements.txt            Python deps.

Install
-------
  pip install -r requirements.txt

The minimum for `--dry-run` work (no DB) is:
  pip install pandas openpyxl pyyaml

Add `psycopg[binary]` for live runs against the warehouse.

Run (customer audience — XLSX + HTML, no JSON)
----------------------------------------------
Live run, full output to ./Output/:

  python dictionary_v2/build_dictionary.py \
      --cohort balboa_ckd \
      --audience customer

Dry-run (no DB connection, useful to confirm the bundle works):

  python dictionary_v2/build_dictionary.py \
      --cohort balboa_ckd \
      --audience customer \
      --dry-run

Other audiences are still available:

  --audience technical   Full dictionary with all debug fields (default).
  --audience sales       Hides Columns sheet, drops PII rows.
  --audience pharma      Hides Tables + Columns, drops PII rows.

What customer audience produces
-------------------------------
  Output/<schema>_dictionary_customer.xlsx
  Output/<schema>_dictionary_customer.html

Customer audience trims sheets to the reviewer-approved layout:
  Summary    11 customer-relevant fields, no metric/value header row.
  Tables     Table, Category, Description, Inclusion Criteria,
             Rows, Columns, Patients (no Data Source / Source Table).
  Columns    Table, Column, Description, Field Type only.
  Variables  No Coding Schema / Implemented / Data Source. Keeps
             both Inclusion Criteria (prose) and Criteria (matcher).

Internal scaffolding tables (standard_profile_data_model,
cohort_patients, dv_tokenized_profile_data) are filtered out for
customer; technical / sales / pharma keep them for debugging.

JSON output is suppressed for customer audience (it's an
internal/debug format only).

Database connection
-------------------
Live runs read DB credentials from a `.env` file in the bundle root.
Copy your existing .env next to introspect_cohort.py before running.

Cohort list
-----------
  balboa_ckd, drg_ckd, mtc_aat, mtc_alzheimers, newtown_ibd,
  newtown_mash, nimbus_asthma, nimbus_az_asthma, nimbus_az_copd,
  nimbus_copd, rmn_alzheimers, rvc_amd_curated, rvc_dr_curated
