# Century data dictionary — runtime bundle

Single zip containing the v2 build path **and** the offline
exact-match discovery tooling.

## Quick start

```bash
pip install -r requirements.txt

# Optional: discover candidate exact matches against a live cohort
# DB. Writes Output/discovery/<cohort>/{report.md, suggested.yaml}.
# With --apply, prompts to inject `match:` blocks straight into
# packs/variables/<source_pack>.yaml (ruamel.yaml required).
python dictionary_v2/discover_exact_matches.py --cohort <slug> \
    --write-suggestions --apply

# Build the dictionary for a cohort + audience.
python dictionary_v2/build_dictionary.py --cohort <slug> \
    --audience customer
```

Audience choices: `technical` | `sales` | `pharma` | `customer`.
See README.md for the full guide.
