# Century data dictionary — runtime bundle

Single zip containing the v2 build path and the offline exact-match
discovery tooling. Generates a customer- or sales-facing data
dictionary for any registered cohort.

For a worked end-to-end example (mtc_aat → sales spec), see
[`run.md`](./run.md).

---

## 1. Folder layout

```
century-dictionary/
├── README.md                            ← you are here
├── run.md                               ← worked example: mtc_aat / sales
├── requirements.txt
├── introspect_cohort.py                 ← Postgres schema walker
├── dictionary_v2/
│   ├── build_dictionary.py              ← main build (audiences)
│   └── discover_exact_matches.py        ← discovery + --apply / --auto-stub
├── scripts/
│   └── validate_packs.py                ← pack lint (no DB needed)
└── packs/                               ← cohort + variable + descriptor packs
    ├── categories.yaml                  ← table → Category map
    ├── column_descriptions.yaml         ← OMOP column semantics
    ├── pii.yaml                         ← PII allowlist + regex
    ├── table_descriptions.yaml          ← table → purpose blurb
    ├── dictionary_layout.yaml           ← per-audience layout overrides
    ├── STYLE.md                         ← prose-quality bar for customer copy
    ├── cohorts/                         ← per-cohort descriptors (13 cohorts)
    └── variables/                       ← shared <disease>_common + per-cohort
```

---

## 2. One-time setup

```bash
unzip century-dictionary.zip
cd century-dictionary
pip install -r requirements.txt

# Warehouse credentials — fill these in:
cat > .env <<'ENV'
PGHOST=warehouse.example.com
PGPORT=5432
PGDATABASE=century
PGUSER=readonly_user
PGPASSWORD=********
PGSSLMODE=require
ENV
```

`requirements.txt` pins:
- `pandas`, `openpyxl` — XLSX writer.
- `pyyaml` — pack parsing.
- `psycopg[binary]` — Postgres driver (live runs only; `--dry-run`
  skips the DB connection).
- `ruamel.yaml` — round-trips packs without destroying comments.
  Required only when running `discover_exact_matches.py --apply`.

---

## 3. Build a dictionary

```bash
python dictionary_v2/build_dictionary.py \
    --cohort <cohort_slug> \
    --audience <audience>
```

### Cohort slugs
balboa_ckd, drg_ckd, mtc_aat, mtc_alzheimers, newtown_ibd,
newtown_mash, nimbus_asthma, nimbus_az_asthma, nimbus_az_copd,
nimbus_copd, rmn_alzheimers, rvc_amd_curated, rvc_dr_curated.

### Audiences

| `--audience` | Sheets | Notes |
|---|---|---|
| `technical` (default) | Summary + Tables + Columns + Variables | Full debug fields, raw SQL Criteria, PII visible. Writes xlsx + html + json. |
| `sales` | Summary + Tables + Variables (no Columns sheet). Summary and Tables use the customer-trimmed layouts; Variables uses the Tempus-style spec (Category, Variable, Description, Value Sets, Notes, Type, Proposal, Completeness). | PII dropped, internal scaffolding tables filtered, JSON suppressed. |
| `pharma` | Summary + Variables | PII dropped. JSON kept. |
| `customer` | Summary, Tables, Columns, Variables (all trimmed) | PII dropped, internal scaffolding tables filtered, JSON suppressed. |

### Other build flags
```bash
--formats xlsx html json   # pick formats (default = all three)
--out-dir /path/to/dir
--dry-run                  # skip DB; pack-only smoke test
```

---

## 4. Exact-match discovery (optional, for tightening Criteria)

The dictionary ships best when each variable's Criteria is a strict
`column IN ('val1', 'val2', ...)` list instead of a fuzzy `ILIKE`
pattern. The discovery script enumerates the actual values your
warehouse holds for each variable and proposes a `match:` block.

### Read-only report
```bash
python dictionary_v2/discover_exact_matches.py --cohort <slug>
# → Output/discovery/<slug>/report.md
```

### Read-only report + suggestions YAML
```bash
python dictionary_v2/discover_exact_matches.py --cohort <slug> \
    --write-suggestions
# → Output/discovery/<slug>/{report.md, suggested.yaml}
```

### Apply match blocks back into packs (interactive, per-variable)
```bash
# Safer: writes ONLY into packs/variables/<slug>.yaml.
# Inherited rows are skipped unless --auto-stub is passed.
python dictionary_v2/discover_exact_matches.py --cohort <slug> \
    --apply --target cohort

# --auto-stub: when --target cohort hits a variable that isn't in
# the cohort pack yet, copy its full base definition from the
# source pack into the cohort pack first, then attach the match
# block. Shared packs are NEVER modified.
python dictionary_v2/discover_exact_matches.py --cohort <slug> \
    --apply --target cohort --auto-stub

# Touches each variable's source pack — including shared
# <disease>_common.yaml files. Only use when the values are
# clinically appropriate for every cohort that includes the source.
python dictionary_v2/discover_exact_matches.py --cohort <slug> \
    --apply --target shared
```

Interactive `--apply` prompts per variable:
```
  Variable: Diagnosis / Alzheimer's
  Source:   packs/variables/adrd_common.yaml
  Target:   packs/variables/mtc_alzheimers.yaml
  Action:   ADD cohort override
  Values:   12 ("Alzheimer disease, late onset", …)
  Reason:   row is inherited from shared pack; discovered values came from one cohort only
  Proceed?  [y]es / [n]o / [a]ll-remaining / [q]uit:
```

- **UPDATE variable** — row already in target pack; only the `match:` block changes.
- **ADD cohort override** — `--auto-stub` is copying a shared row into the cohort pack.
- `all` accepts every remaining row; `quit` aborts (no files written).

Add `--apply-yes` to skip prompts entirely (scripted runs).

### Where should match values live?

| Pack | Scope | When to put values here |
|---|---|---|
| `<cohort>.yaml` (e.g. `mtc_aat.yaml`) | One cohort only | **Default** for newly-discovered values. `--target cohort --auto-stub` writes here. |
| `<disease>_common.yaml` (e.g. `aat_common.yaml`) | All cohorts of one disease | Promote here only after confirming values are valid across every cohort that includes the pack. |
| Umbrella `<x>_common.yaml` (e.g. `adrd_common.yaml`) | A whole disease family | Promote here only after confirming values are valid across the umbrella. |

The default flow keeps shared packs untouched. Promotion is a deliberate follow-up.

---

## 5. Validate packs offline (no DB)

```bash
python scripts/validate_packs.py --strict
```
Lints every cohort's pack chain (cohort → variables_pack → includes)
for missing fields, dangling refs, malformed `match:` blocks,
unknown `proposal:` values, etc. Exits non-zero on errors.

---

## 6. Troubleshooting

- **`ModuleNotFoundError: psycopg`** — install deps:
  `pip install -r requirements.txt`. Or use `--dry-run` to skip DB.
- **`--apply` says "ruamel.yaml is not installed"** —
  `pip install ruamel.yaml`. The script refuses to write without
  it because pyyaml round-trip would destroy comments.
- **`--apply` exits 2 with "requires --target"** — pick
  `--target cohort` (safer) or `--target shared`.
- **`--apply --target cohort` skips most variables** — they live
  in shared packs and the cohort pack doesn't have them yet.
  Pass `--auto-stub` to copy each shared row into the cohort
  pack as a per-cohort override before applying the match block.
- **Empty Variables sheet** — your cohort's variables pack is a
  placeholder pulling from `<disease>_common.yaml`. That's normal;
  the build resolves `include:` chains automatically.
