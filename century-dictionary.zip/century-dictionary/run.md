# Walkthrough: generate the **sales** data dictionary for `mtc_aat`

End-to-end example. Produces the Tempus-style sales spec for the
MTC AAT cohort (anti-amyloid therapy patients): a single-sheet
workbook with the columns the partner reviewer asked for.

---

## What you'll end up with

```
Output/
├── mtc__aat_cohort_dictionary_sales.xlsx      ← hand this to the reviewer
└── mtc__aat_cohort_dictionary_sales.html      ← same content, browsable
```

Sheets in the xlsx:
- **Summary** — cohort cover (provider, disease, patient count, date coverage).
- **Variables** — Tempus-style spec with these columns:
  `Category | Variable | Description | Value Sets | Notes | Type | Proposal | Completeness`

JSON is intentionally not produced for the sales audience — the partner
bundle never carries the internal `CohortModel` dump.

---

## Step 0 — prerequisites

You only need to do this once per environment.

```bash
unzip century-dictionary.zip
cd century-dictionary

pip install -r requirements.txt

# Warehouse credentials:
cat > .env <<'ENV'
PGHOST=warehouse.example.com
PGPORT=5432
PGDATABASE=century
PGUSER=readonly_user
PGPASSWORD=********
PGSSLMODE=require
ENV
```

---

## Step 1 — sanity-check offline (no DB needed)

Confirms the packs load and the layout is correct without touching
the warehouse:

```bash
python dictionary_v2/build_dictionary.py \
    --cohort mtc_aat \
    --audience sales \
    --dry-run
```

Expect to see:
```
Wrote Output/mtc__aat_cohort_dictionary_sales.xlsx
Wrote Output/mtc__aat_cohort_dictionary_sales.html
```

If you open the xlsx, the `Variables` sheet header row will read
exactly:
```
Category | Variable | Description | Value Sets | Notes | Type | Proposal | Completeness
```

`Value Sets` and `Proposal` cells will be empty — those come from
curated YAML fields (see Step 3 below). The dry-run skips
DB-derived columns, so `Completeness` is `—`.

---

## Step 2 — real build against the warehouse

```bash
python dictionary_v2/build_dictionary.py \
    --cohort mtc_aat \
    --audience sales
```

`Completeness` is now populated from live cohort counts. Hand off
the xlsx + html as the sales artifact.

---

## Step 3 (optional) — populate `Value Sets` and `Proposal`

Both columns are authored in the cohort's variables YAML
(`packs/variables/mtc_aat.yaml`) under each `variable:` row.
Edit the file directly; the next `--audience sales` run picks them up.

```yaml
- category: Demographics
  variable: Education level
  description: The patient's highest level of education received.
  table: observation
  column: value_as_concept_name
  value_set:                              # ← curated clinical reference values
    - Less than high school
    - High school diploma or equivalent
    - Some college, no degree
    - Associate degree
    - Bachelor's degree
    - Master's degree
    - Doctoral or professional degree
  proposal: Custom                        # ← Standard | Custom
```

The `value_set:` cell renders newline-separated in the workbook
(matches the reference Google sheet). `proposal:` must be exactly
`Standard` or `Custom` when set; the validator rejects anything
else.

If you accidentally write a scalar instead of a list:
```yaml
value_set: "Yes, No, Unknown"             # ← scalar; auto-split by builder
```
the renderer normalizes it to a 3-item list, but the validator
will still flag it as an error so you fix the YAML.

After editing:
```bash
# Lint the packs (no DB required):
python scripts/validate_packs.py --strict

# Re-run the build:
python dictionary_v2/build_dictionary.py --cohort mtc_aat --audience sales
```

---

## Step 4 (optional) — tighten Criteria with discovery

This addresses the reviewer's "Criteria should be exact matches,
not ILIKE" feedback. Replaces fuzzy `criteria: drug_concept_name
ILIKE '%lecanemab%'` with strict `match: { column, values }` blocks
populated from the live cohort.

The sales sheet doesn't show a `Criteria` column directly, but
tightening Criteria still affects which rows feed `Completeness`
and the underlying value distributions, so it's worth doing once
per cohort.

```bash
# 4a. Read-only report — what does mtc_aat actually contain for
#     each variable's existing broad criteria?
python dictionary_v2/discover_exact_matches.py --cohort mtc_aat
# → Output/discovery/mtc_aat/report.md

# 4b. Apply observed values into packs/variables/mtc_aat.yaml.
#     --auto-stub copies each inherited row from the shared
#     aat_common pack into mtc_aat.yaml first, then attaches the
#     match block. Walks one variable at a time with a
#     [UPDATE]/[ADD cohort override] prompt.
python dictionary_v2/discover_exact_matches.py \
    --cohort mtc_aat \
    --apply --target cohort --auto-stub
```

After step 4b, `git diff packs/variables/mtc_aat.yaml` shows the
exact rows that were added/updated. Each new row carries a
provenance comment:

```yaml
  # Auto-stubbed from packs/variables/aat_common.yaml via discover_exact_matches.py --auto-stub. Verify clinical fit before shipping.
  - category: Medications
    variable: Anti-amyloid Therapy (Administration)
    table: drug_exposure
    column: drug_concept_name
    criteria: drug_concept_name ILIKE '%lecanemab%' OR ...
    match:
      column: drug_concept_name
      values:
        - Lecanemab
        - Lecanemab-irmb
        - Leqembi
        - Donanemab-azbt
        - Kisunla
```

For non-interactive (CI) use:
```bash
python dictionary_v2/discover_exact_matches.py \
    --cohort mtc_aat \
    --apply-yes --target cohort --auto-stub
```

Re-run the build to pick up the new match blocks:
```bash
python dictionary_v2/build_dictionary.py --cohort mtc_aat --audience sales
```

---

## Quick reference

| Task | Command |
|---|---|
| Sanity-check (no DB) | `python dictionary_v2/build_dictionary.py --cohort mtc_aat --audience sales --dry-run` |
| Build sales dictionary | `python dictionary_v2/build_dictionary.py --cohort mtc_aat --audience sales` |
| Read-only discovery | `python dictionary_v2/discover_exact_matches.py --cohort mtc_aat` |
| Apply match blocks | `python dictionary_v2/discover_exact_matches.py --cohort mtc_aat --apply --target cohort --auto-stub` |
| Validate packs | `python scripts/validate_packs.py --strict` |
