# Walkthrough: generate the **sales** data dictionary for `mtc_aat`

End-to-end example. Produces the Tempus-style sales spec for the
MTC AAT cohort (anti-amyloid therapy patients) — a three-sheet
workbook (Summary cover, Tables overview, Variables spec) with
the columns the partner reviewer asked for.

---

## What you'll end up with

```
Output/
├── mtc__aat_cohort_dictionary_sales.xlsx      ← hand this to the reviewer
└── mtc__aat_cohort_dictionary_sales.html      ← same content, browsable
```

Sheets in the xlsx (three; Columns is intentionally not produced
for sales — a partner reads Variables for clinical content, and an
engineer who needs the column-level schema map can pull the
technical-audience output instead):

- **Summary** — cohort cover (provider, disease, patient count, date coverage).
- **Tables** — customer-trimmed: `Table | Category | Description | Inclusion Criteria | Rows | Columns | Patients`. Internal scaffolding tables (`cohort_patients`, `standard_profile_data_model`, etc.) are filtered out via `packs/dictionary_layout.yaml`.
- **Variables** — Tempus-style spec: `Category | Variable | Description | Value Sets | Notes | Type | Proposal | Completeness`. Variables that have no data in the cohort (`Implemented = No`) are dropped automatically.

JSON is intentionally not produced for the sales audience — the partner
bundle never carries the internal `CohortModel` dump.

---

## Step 0 — prerequisites

You only need to do this once per environment.

```bash
unzip century-dictionary.zip
cd century-dictionary

pip install -r requirements.txt

# Warehouse credentials:
cat > .env <<'ENV'
PGHOST=warehouse.example.com
PGPORT=5432
PGDATABASE=century
PGUSER=readonly_user
PGPASSWORD=********
PGSSLMODE=require
ENV
```

---

## Step 1 — sanity-check offline (no DB needed)

Confirms the packs load and the layout is correct without touching
the warehouse:

```bash
python dictionary_v2/build_dictionary.py \
    --cohort mtc_aat \
    --audience sales \
    --dry-run
```

Expect to see:
```
Wrote Output/mtc__aat_cohort_dictionary_sales.xlsx
Wrote Output/mtc__aat_cohort_dictionary_sales.html
```

If you open the xlsx, the `Variables` sheet header row will read
exactly:
```
Category | Variable | Description | Value Sets | Notes | Type | Proposal | Completeness
```

`Value Sets` and `Completeness` are empty / `—` in dry-run because
both are DB-derived. At runtime, `Value Sets` shows the cohort's
observed top-N values for the variable's column, newline-separated.
`Proposal` is YAML-only (see Step 3 below).

---

## Step 2 — real build against the warehouse

```bash
python dictionary_v2/build_dictionary.py \
    --cohort mtc_aat \
    --audience sales
```

`Completeness` is now populated from live cohort counts. Variables
the cohort doesn't actually carry data for (`Implemented = No`)
are dropped automatically from the sales / customer artifacts —
they'd otherwise render as 0% rows and add noise. Internal
audiences (`technical`, `pharma`) keep them so QA can see gaps.

Hand off the xlsx + html as the sales artifact.

---

## Step 3 (optional) — set `Proposal` per variable

`Proposal` is the only column on the sales sheet authored from
YAML. Set it on each variable in the cohort's pack
(`packs/variables/mtc_aat.yaml`):

```yaml
- category: Demographics
  variable: Education level
  description: The patient's highest level of education received.
  table: observation
  column: value_as_concept_name
  proposal: Custom                        # ← Standard | Custom
```

Must be exactly `Standard` or `Custom` when set; the validator
rejects anything else.

`Value Sets` is data-driven and not configurable — the cell
always reflects what the cohort actually contains. A data
dictionary that claims a value the cohort doesn't carry is wrong
by definition.

After editing:
```bash
# Lint the packs (no DB required):
python scripts/validate_packs.py --strict

# Re-run the build:
python dictionary_v2/build_dictionary.py --cohort mtc_aat --audience sales
```

---

## Step 4 (optional) — tighten Criteria with discovery

This addresses the reviewer's "Criteria should be exact matches,
not ILIKE" feedback. Replaces fuzzy `criteria: drug_concept_name
ILIKE '%lecanemab%'` with strict `match: { column, values }` blocks
populated from the live cohort.

The sales sheet doesn't show a `Criteria` column directly, but
tightening Criteria still affects which rows feed `Completeness`
and the underlying value distributions, so it's worth doing once
per cohort.

```bash
# 4a. Read-only report — what does mtc_aat actually contain for
#     each variable's existing broad criteria?
python dictionary_v2/discover_exact_matches.py --cohort mtc_aat
# → Output/discovery/mtc_aat/report.md

# 4b. Apply observed values into packs/variables/mtc_aat.yaml.
#     --auto-stub copies each inherited row from the shared
#     aat_common pack into mtc_aat.yaml first, then attaches the
#     match block. Walks one variable at a time with a
#     [UPDATE]/[ADD cohort override] prompt.
python dictionary_v2/discover_exact_matches.py \
    --cohort mtc_aat \
    --apply --target cohort --auto-stub
```

After step 4b, `git diff packs/variables/mtc_aat.yaml` shows the
exact rows that were added/updated. Each new row carries a
provenance comment:

```yaml
  # Auto-stubbed from packs/variables/aat_common.yaml via discover_exact_matches.py --auto-stub. Verify clinical fit before shipping.
  - category: Medications
    variable: Anti-amyloid Therapy (Administration)
    table: drug_exposure
    column: drug_concept_name
    criteria: drug_concept_name ILIKE '%lecanemab%' OR ...
    match:
      column: drug_concept_name
      values:
        - Lecanemab
        - Lecanemab-irmb
        - Leqembi
        - Donanemab-azbt
        - Kisunla
```

For non-interactive (CI) use:
```bash
python dictionary_v2/discover_exact_matches.py \
    --cohort mtc_aat \
    --apply-yes --target cohort --auto-stub
```

Re-run the build to pick up the new match blocks:
```bash
python dictionary_v2/build_dictionary.py --cohort mtc_aat --audience sales
```

---

## Quick reference

| Task | Command |
|---|---|
| Sanity-check (no DB) | `python dictionary_v2/build_dictionary.py --cohort mtc_aat --audience sales --dry-run` |
| Build sales dictionary | `python dictionary_v2/build_dictionary.py --cohort mtc_aat --audience sales` |
| Read-only discovery | `python dictionary_v2/discover_exact_matches.py --cohort mtc_aat` |
| Apply match blocks | `python dictionary_v2/discover_exact_matches.py --cohort mtc_aat --apply --target cohort --auto-stub` |
| Validate packs | `python scripts/validate_packs.py --strict` |
